
//define your default values here, if there are different values in config.json, they are overwritten.
char mqtt_server[40] = "0.0.0.0";
char mqtt_port[6] = "1883";
char idpass[40] = "admin";
char usuario[40] = "ibrx";
//default custom static IP
char static_ip[16] = "192.168.25.50";
char static_gw[16] = "192.168.25.1";
char static_sn[16] = "255.255.255.0";
char tipo[15] = "DHCP";
#define RESET 4



//flag for saving data
bool shouldSaveConfig = false;

//callback notifying us of the need to save config
void saveConfigCallback () {
  Serial.println("Should save config");
  shouldSaveConfig = true;
}


void sistemafs(String nserial) {



  //clean FS, for testing
  //SPIFFS.format();


  //read configuration from FS json
  Serial.println("mounting FS...");

  if (SPIFFS.begin()) {
    Serial.println("mounted file system");
    if (SPIFFS.exists("/config.json")) {
      //file exists, reading and loading
      Serial.println("reading config file");
      File configFile = SPIFFS.open("/config.json", "r");
      if (configFile) {
        Serial.println("opened config file");
        size_t size = configFile.size();
        // Allocate a buffer to store contents of the file.
        std::unique_ptr<char[]> buf(new char[size]);

        configFile.readBytes(buf.get(), size);
        DynamicJsonBuffer jsonBuffer;
        JsonObject& json = jsonBuffer.parseObject(buf.get());
        json.printTo(Serial);
        if (json.success()) {
          Serial.println("\nparsed json");
          strcpy(mqtt_server, json["mqtt_server"]);
          strcpy(mqtt_port, json["mqtt_port"]);
          strcpy(idpass, json["idpass"]);
          strcpy(tipo, json["tipo"]);
          strcpy(usuario, json["usuario"]);

          Serial.println("S1 = " + String(tipo));

          if (json["ip"]) {
            Serial.println("setting custom ip from config");
            //static_ip = json["ip"];
            strcpy(static_ip, json["ip"]);
            strcpy(static_gw, json["gateway"]);
            strcpy(static_sn, json["subnet"]);

            Serial.println(static_ip);
            /*            Serial.println("converting ip");
              IPAddress ip = ipFromCharArray(static_ip);
              Serial.println(ip);*/
          } else {
            Serial.println("no custom ip in config");
          }
        } else {
          Serial.println("failed to load json config");
        }
      }
    }

  } else {
    Serial.println("failed to mount FS");
  }

  //end read
  // The extra parameters to be configured (can be either global or just in the setup)
  // After connecting, parameter.getValue() will get you the configured value
  // id/name placeholder/prompt default length
  //ADICIONA CAMPOS NO WIFI MANAGER

  char conv[600];
  String page = "<select id='s11' onchange='show()'><option selected disabled hidden>";
  page += String(tipo);
  page += "</option><option value='DHCP'>DHCP</option><option value='Estatico'>Estático</option></select>";
  page += "<script>function show(){document.getElementById('tipo').value = document.getElementById('s11').value;";
  page += "if(document.getElementById('s11').value =='DHCP'){document.getElementById('painel').style.display = 'none';}else{document.getElementById('painel').style.display = 'inline';}}";
  page += "</script><body onload='show()'><div id='painel'>";
  page.toCharArray(conv, 600);

  WiFiManagerParameter custom_text4("Servidor");
  WiFiManagerParameter custom_mqtt_server("server_mqtt", "Servidor", mqtt_server, 40);
  WiFiManagerParameter custom_text6("Porta MQTT");
  WiFiManagerParameter custom_mqtt_port("mqtt_port", "Porta MQTT", mqtt_port, 40);
  WiFiManagerParameter custom_text5("Usuário MQTT");
  WiFiManagerParameter custom_usuario("usuario", "Usuário servidor MQTT", usuario, 40);
  WiFiManagerParameter custom_text3("Senha MQTT");
  WiFiManagerParameter custom_idpass("idpass", "Senha servidor MQTT", idpass, 40);
  WiFiManagerParameter custom_text1("Definições IP<br>");
  WiFiManagerParameter custom_text2(conv);
  WiFiManagerParameter custom_tipo("tipo", "Modo de operar", tipo, 40, "hidden");


  //WiFiManager
  //Local intialization. Once its business is done, there is no need to keep it around
  WiFiManager wifiManager;
  //wifiManager.resetSettings();


  //set config save notify callback
  wifiManager.setSaveConfigCallback(saveConfigCallback);
  //set static ip
  IPAddress _ip, _gw, _sn;
  _ip.fromString(static_ip);
  _gw.fromString(static_gw);
  _sn.fromString(static_sn);

  if ( strcmp(tipo, "DHCP") == 0) {
    Serial.println(">>>>> DHCP");
  } else {
    Serial.println(">>>>> Estatico");
    WiFi.config(_ip,_gw,_sn);
    wifiManager.setSTAStaticIPConfig(_ip, _gw, _sn);
  }



  //add all your parameters here
  // PARAMETROS DOS CAMPOS WIFI MANAGER
  wifiManager.addParameter(&custom_text4);
  wifiManager.addParameter(&custom_mqtt_server);
  wifiManager.addParameter(&custom_text6);
  wifiManager.addParameter(&custom_mqtt_port);
  wifiManager.addParameter(&custom_text5);
  wifiManager.addParameter(&custom_usuario);
  wifiManager.addParameter(&custom_text3);
  wifiManager.addParameter(&custom_idpass);
  wifiManager.addParameter(&custom_text1);
  wifiManager.addParameter(&custom_text2);
  wifiManager.addParameter(&custom_tipo);



  //wifiManager.addParameter(&custom_blynk_token);
  //sets timeout until configuration portal gets turned off
  //useful to make it all retry or go to sleep
  //in seconds
  //wifiManager.setTimeout(190);
  char serial[40];
  nserial = "CasaWeb EXP14 - " + nserial;
  nserial.toCharArray(serial, 40);
  if ( digitalRead(RESET) == 0 ) {
    if (!wifiManager.startConfigPortal(serial)) {
      Serial.println("failed to connect and hit timeout");
      //reset and try again, or maybe put it to deep sleep
      delay(3000);
      ESP.restart();
      delay(1000);
    }
  }

  //if you get here you have connected to the WiFi
  WiFi.begin();
  Serial.println("Conectado... :)");

  //read updated parameters
  // PARAMETROS WIFI MANAGER
  strcpy(idpass, custom_idpass.getValue());
  strcpy(usuario, custom_usuario.getValue());
  strcpy(mqtt_server, custom_mqtt_server.getValue());
  strcpy(tipo, custom_tipo.getValue());



  //save the custom parameters to FS
  if (shouldSaveConfig) {
    Serial.println("saving config");
    DynamicJsonBuffer jsonBuffer;
    JsonObject& json = jsonBuffer.createObject();
    json["mqtt_server"] = mqtt_server;
    json["mqtt_port"] = mqtt_port;
    json["idpass"] = idpass;
    json["tipo"] = tipo;
    json["usuario"] = usuario;


    json["ip"] = WiFi.localIP().toString();
    json["gateway"] = WiFi.gatewayIP().toString();
    json["subnet"] = WiFi.subnetMask().toString();

    File configFile = SPIFFS.open("/config.json", "w");
    if (!configFile) {
      Serial.println("failed to open config file for writing");
    }

    json.printTo(Serial);
    json.printTo(configFile);
    configFile.close();
    //end save
  }


}
