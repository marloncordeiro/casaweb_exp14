/*
   CasaWeb EXP14 - Versão 1 - 30/11/2018

   PINAGEM
   D2 {04} Reset
   D6 {13} LED Verde
   D7 {12} LED Vermelho
 */
#include <Arduino.h>
#include <FS.h>
#include <ESP8266WiFi.h>
#include <PubSubClient.h>
#include <WiFiManager.h>          //https://github.com/tzapu/WiFiManager
#include <ArduinoJson.h>          //https://github.com/bblanchon/ArduinoJson
#include <DNSServer.h>
//#include <EEPROM.h>

#include "sistema_fs.h"
#include <Ticker.h>
Ticker tickerOSWatch;

#define OSWATCH_RESET_TIME 30
#define led_verde 13
#define led_vermelho 12
#define RESET 4

char hostname [20];
String hostname_conv;
char message_buff[100];
String serial;
String status;
String sensor1, sensor2, sensor3;
String id;
String comandoset1,comandostate1,comandoset2,comandostate2,comandoset3,comandostate3,comandoset4,comandostate4;
String comandoset5,comandostate5,comandoset6,comandostate6,comandoset7,comandostate7,comandoset8,comandostate8;
String comandoset9,comandostate9,comandoset10,comandostate10,comandoset11,comandostate11,comandoset12,comandostate12;
String comandoset13,comandostate13,comandoset14,comandostate14;
char nomeserver[20];
char data [20];
unsigned long now;
long lastMsg = 0;
int ID = ESP.getChipId();
String nserial = String(ID);
int contador = 0;

WiFiClient espClient;
PubSubClient client(espClient);

static unsigned long last_loop;

void ICACHE_RAM_ATTR osWatch(void) {
        unsigned long t = millis();
        unsigned long last_run = abs(t - last_loop);
        if(last_run >= (OSWATCH_RESET_TIME * 1000)) {

                ESP.restart(); // normal reboot
                Serial.println("Reiniciado");
                //ESP.reset();  // hard reset
        }
}

void pubMQTT(String topic, String topic_val) {

        client.publish(topic.c_str(), topic_val.c_str(), true);

}

void reconnect() {


        Serial.print("Attempting MQTT connection...");

        if (client.connect(nomeserver, usuario, idpass)) {
                Serial.println("connected");
                client.subscribe(serial.c_str());
                client.subscribe(comandoset1.c_str());
                client.subscribe(comandoset2.c_str());
                client.subscribe(comandoset3.c_str());
                client.subscribe(comandoset4.c_str());
                client.subscribe(comandoset5.c_str());
                client.subscribe(comandoset6.c_str());
                client.subscribe(comandoset7.c_str());
                client.subscribe(comandoset8.c_str());
                client.subscribe(comandoset9.c_str());
                client.subscribe(comandoset10.c_str());
                client.subscribe(comandoset11.c_str());
                client.subscribe(comandoset12.c_str());
                client.subscribe(comandoset13.c_str());
                client.subscribe(comandoset14.c_str());
                pubMQTT("homeassistant/light/" + nserial + "/r1/config", "{\"name\":\"" + nserial + "_r1\", \"command_topic\": \"homeassistant/light/" + nserial + "/r1/set\", \"state_topic\": \"homeassistant/light/" + nserial + "/r1/state\"}");
                pubMQTT("homeassistant/light/" + nserial + "/r2/config", "{\"name\":\"" + nserial + "_r2\", \"command_topic\": \"homeassistant/light/" + nserial + "/r2/set\", \"state_topic\": \"homeassistant/light/" + nserial + "/r2/state\"}");
                pubMQTT("homeassistant/light/" + nserial + "/r3/config", "{\"name\":\"" + nserial + "_r3\", \"command_topic\": \"homeassistant/light/" + nserial + "/r3/set\", \"state_topic\": \"homeassistant/light/" + nserial + "/r3/state\"}");
                pubMQTT("homeassistant/light/" + nserial + "/r4/config", "{\"name\":\"" + nserial + "_r4\", \"command_topic\": \"homeassistant/light/" + nserial + "/r4/set\", \"state_topic\": \"homeassistant/light/" + nserial + "/r4/state\"}");
                pubMQTT("homeassistant/light/" + nserial + "/r5/config", "{\"name\":\"" + nserial + "_r5\", \"command_topic\": \"homeassistant/light/" + nserial + "/r5/set\", \"state_topic\": \"homeassistant/light/" + nserial + "/r5/state\"}");
                pubMQTT("homeassistant/light/" + nserial + "/r6/config", "{\"name\":\"" + nserial + "_r6\", \"command_topic\": \"homeassistant/light/" + nserial + "/r6/set\", \"state_topic\": \"homeassistant/light/" + nserial + "/r6/state\"}");
                pubMQTT("homeassistant/light/" + nserial + "/r7/config", "{\"name\":\"" + nserial + "_r7\", \"command_topic\": \"homeassistant/light/" + nserial + "/r7/set\", \"state_topic\": \"homeassistant/light/" + nserial + "/r7/state\"}");
                pubMQTT("homeassistant/light/" + nserial + "/r8/config", "{\"name\":\"" + nserial + "_r8\", \"command_topic\": \"homeassistant/light/" + nserial + "/r8/set\", \"state_topic\": \"homeassistant/light/" + nserial + "/r8/state\"}");
                pubMQTT("homeassistant/light/" + nserial + "/r9/config", "{\"name\":\"" + nserial + "_r9\", \"command_topic\": \"homeassistant/light/" + nserial + "/r9/set\", \"state_topic\": \"homeassistant/light/" + nserial + "/r9/state\"}");
                pubMQTT("homeassistant/light/" + nserial + "/r10/config", "{\"name\":\"" + nserial + "_r10\", \"command_topic\": \"homeassistant/light/" + nserial + "/r10/set\", \"state_topic\": \"homeassistant/light/" + nserial + "/r10/state\"}");
                pubMQTT("homeassistant/light/" + nserial + "/r11/config", "{\"name\":\"" + nserial + "_r11\", \"command_topic\": \"homeassistant/light/" + nserial + "/r11/set\", \"state_topic\": \"homeassistant/light/" + nserial + "/r11/state\"}");
                pubMQTT("homeassistant/light/" + nserial + "/r12/config", "{\"name\":\"" + nserial + "_r12\", \"command_topic\": \"homeassistant/light/" + nserial + "/r12/set\", \"state_topic\": \"homeassistant/light/" + nserial + "/r12/state\"}");
                pubMQTT("homeassistant/light/" + nserial + "/r13/config", "{\"name\":\"" + nserial + "_r13\", \"command_topic\": \"homeassistant/light/" + nserial + "/r13/set\", \"state_topic\": \"homeassistant/light/" + nserial + "/r13/state\"}");
                pubMQTT("homeassistant/light/" + nserial + "/r14/config", "{\"name\":\"" + nserial + "_r14\", \"command_topic\": \"homeassistant/light/" + nserial + "/r14/set\", \"state_topic\": \"homeassistant/light/" + nserial + "/r14/state\"}");
                pubMQTT("homeassistant/binary_sensor/" + nserial + "/s1/config", "{\"name\":\"" + nserial + "_s1\", \"state_topic\": \"homeassistant/binary_sensor/" + nserial + "/s1/state\"}");
                pubMQTT("homeassistant/binary_sensor/" + nserial + "/s2/config", "{\"name\":\"" + nserial + "_s2\", \"state_topic\": \"homeassistant/binary_sensor/" + nserial + "/s2/state\"}");
                pubMQTT("homeassistant/binary_sensor/" + nserial + "/s3/config", "{\"name\":\"" + nserial + "_s3\", \"state_topic\": \"homeassistant/binary_sensor/" + nserial + "/s3/state\"}");
                digitalWrite(led_verde, 1);
                digitalWrite(led_vermelho, 0);
                contador = 0;


        } else {
                Serial.print("failed, rc=");
                Serial.print(client.state());
                Serial.println(" Tentando conectar novamente em 2 segundos");
                digitalWrite(led_verde, 0);
                digitalWrite(led_vermelho, 1);
                delay(2000);
                contador++;
                if (contador > 10) ESP.restart();

        }

}



void callback(char* topic, byte * payload, unsigned int length) {

        unsigned int i = 0;
        for (i = 0; i < length; i++) {
                message_buff[i] = payload[i];
        }
        message_buff[i] = '\0';

        String msgString = String(message_buff);
        String topico = String(topic);

        //Serial.println("Topic: " + topico);
        //Serial.println("Payload: " + msgString);
        digitalWrite(led_verde, 0);
        digitalWrite(led_vermelho, 1);
        lastMsg = millis();
        if (topico == comandoset1 and msgString == "OFF") {
                Serial.write("w");
                Serial.write(0x0A);
        }
        if (topico == comandoset1 and msgString == "ON") {
                Serial.write("w");
                Serial.write(0x0B);
        }

        if (topico == comandoset2 and msgString == "OFF") {
                Serial.write("w");
                Serial.write(0x14);
        }
        if (topico == comandoset2 and msgString == "ON") {
                Serial.write("w");
                Serial.write(0x15);
        }

        if (topico == comandoset3 and msgString == "OFF") {
                Serial.write("w");
                Serial.write(0x1e);
        }
        if (topico == comandoset3 and msgString == "ON") {
                Serial.write("w");
                Serial.write(0x1f);
        }

        if (topico == comandoset4 and msgString == "OFF") {
                Serial.write("w");
                Serial.write(0x28);
        }
        if (topico == comandoset4 and msgString == "ON") {
                Serial.write("w");
                Serial.write(0x29);
        }

        if (topico == comandoset5 and msgString == "OFF") {
                Serial.write("w");
                Serial.write(0x32);
        }
        if (topico == comandoset5 and msgString == "ON") {
                Serial.write("w");
                Serial.write(0x33);
        }

        if (topico == comandoset6 and msgString == "OFF") {
                Serial.write("w");
                Serial.write(0x3c);
        }
        if (topico == comandoset6 and msgString == "ON") {
                Serial.write("w");
                Serial.write(0x3d);
        }

        if (topico == comandoset7 and msgString == "OFF") {
                Serial.write("w");
                Serial.write(0x46);
        }
        if (topico == comandoset7 and msgString == "ON") {
                Serial.write("w");
                Serial.write(0x47);
        }

        if (topico == comandoset8 and msgString == "OFF") {
                Serial.write("w");
                Serial.write(0x50);
        }
        if (topico == comandoset8 and msgString == "ON") {
                Serial.write("w");
                Serial.write(0x51);
        }

        if (topico == comandoset9 and msgString == "OFF") {
                Serial.write("w");
                Serial.write(0x5a);
        }
        if (topico == comandoset9 and msgString == "ON") {
                Serial.write("w");
                Serial.write(0x5b);
        }

        if (topico == comandoset10 and msgString == "OFF") {
                Serial.write("w");
                Serial.write(0x64);
        }
        if (topico == comandoset10 and msgString == "ON") {
                Serial.write("w");
                Serial.write(0x65);
        }

        if (topico == comandoset11 and msgString == "OFF") {
                Serial.write("w");
                Serial.write(0x6e);
        }
        if (topico == comandoset11 and msgString == "ON") {
                Serial.write("w");
                Serial.write(0x6f);
        }

        if (topico == comandoset12 and msgString == "OFF") {
                Serial.write("w");
                Serial.write(0x78);
        }
        if (topico == comandoset12 and msgString == "ON") {
                Serial.write("w");
                Serial.write(0x79);
        }

        if (topico == comandoset13 and msgString == "OFF") {
                Serial.write("w");
                Serial.write(0x82);
        }
        if (topico == comandoset13 and msgString == "ON") {
                Serial.write("w");
                Serial.write(0x83);
        }

        if (topico == comandoset14 and msgString == "OFF") {
                Serial.write("w");
                Serial.write(0x8c);
        }
        if (topico == comandoset14 and msgString == "ON") {
                Serial.write("w");
                Serial.write(0x8d);
        }



        delay(30);
        digitalWrite(led_verde, 1);
        digitalWrite(led_vermelho, 0);



}

void setup() {
        Serial.begin(9600);
        //setup_wifi();
        client.setServer(mqtt_server, atoi(mqtt_port));
        client.setCallback(callback);

        //CONFIGURAÇÕES DAS SAÍDAS
        pinMode(led_verde, OUTPUT); // Led Verde
        pinMode(led_vermelho, OUTPUT);
        pinMode(RESET, INPUT_PULLUP);//CLEAR
        pinMode(2, OUTPUT);

        digitalWrite(led_vermelho, 1);
        digitalWrite(led_verde, 0);
        delay(1000);
        digitalWrite(led_verde, 1);


        comandoset1 = "homeassistant/light/" + nserial + "/r1/set";
        comandostate1 = "homeassistant/light/" + nserial + "/r1/state";
        comandoset2 = "homeassistant/light/" + nserial + "/r2/set";
        comandostate2 = "homeassistant/light/" + nserial + "/r2/state";
        comandoset3 = "homeassistant/light/" + nserial + "/r3/set";
        comandostate3 = "homeassistant/light/" + nserial + "/r3/state";
        comandoset4 = "homeassistant/light/" + nserial + "/r4/set";
        comandostate4 = "homeassistant/light/" + nserial + "/r4/state";
        comandoset5 = "homeassistant/light/" + nserial + "/r5/set";
        comandostate5 = "homeassistant/light/" + nserial + "/r5/state";
        comandoset6 = "homeassistant/light/" + nserial + "/r6/set";
        comandostate6 = "homeassistant/light/" + nserial + "/r6/state";
        comandoset7 = "homeassistant/light/" + nserial + "/r7/set";
        comandostate7 = "homeassistant/light/" + nserial + "/r7/state";
        comandoset8 = "homeassistant/light/" + nserial + "/r8/set";
        comandostate8 = "homeassistant/light/" + nserial + "/r8/state";
        comandoset9 = "homeassistant/light/" + nserial + "/r9/set";
        comandostate9 = "homeassistant/light/" + nserial + "/r9/state";
        comandoset10 = "homeassistant/light/" + nserial + "/r10/set";
        comandostate10 = "homeassistant/light/" + nserial + "/r10/state";
        comandoset11 = "homeassistant/light/" + nserial + "/r11/set";
        comandostate11 = "homeassistant/light/" + nserial + "/r11/state";
        comandoset12 = "homeassistant/light/" + nserial + "/r12/set";
        comandostate12 = "homeassistant/light/" + nserial + "/r12/state";
        comandoset13 = "homeassistant/light/" + nserial + "/r13/set";
        comandostate13 = "homeassistant/light/" + nserial + "/r13/state";
        comandoset14 = "homeassistant/light/" + nserial + "/r14/set";
        comandostate14 = "homeassistant/light/" + nserial + "/r14/state";

        sensor1 = "homeassistant/binary_sensor/" + nserial + "/s1/state";
        sensor2 = "homeassistant/binary_sensor/" + nserial + "/s2/state";
        sensor3 = "homeassistant/binary_sensor/" + nserial + "/s3/state";


        String nserial = String(ID);
        hostname_conv="CASAWEB_" + nserial;
        serial = nserial + "/comando";
        status = nserial + "/status";

        id = nserial + "/id";
        Serial.println("");
        Serial.println("-----------------------------");
        Serial.println("CasaWeb EXP14");
        Serial.println("Rev 17/12/2019");
        Serial.println("Número de série = " + nserial);
        Serial.println(F(__DATE__));
        Serial.println("-----------------------------");
        Serial.println(" ");
        nserial.toCharArray(nomeserver, 20);
        hostname_conv.toCharArray(hostname, 20);
        sistemafs(nserial); // Inicia sistema de gravação de arquivos e WIFI MANAGER


        
        wifi_station_set_hostname(hostname); // HOSTNAME

        id = nserial + "/id";

        ESP.wdtDisable();
        last_loop = millis();
        tickerOSWatch.attach_ms(((OSWATCH_RESET_TIME / 3) * 1000), osWatch);
}




void loop() {

        if (Serial.available() > 0) //verifica se tem dados diponível para leitura
        {
                Serial.readBytesUntil (13, data, 19); // read bytes (max. 19 ou 33 ) from buffer, untill <CR> (13). store bytes in data. count the bytes recieved.

        }

        client.loop();
        now = millis();
        if (now - lastMsg > 1000) {
                if (!client.connected()) {
                        reconnect();
                }
                int contador = 0;
                int rst = 0;

                lastMsg = now;
                pubMQTT(nserial + "/status", String(data));
                pubMQTT("seriais/" + nserial, String(nserial));
                if (String(data[1]) == "1" ) pubMQTT(comandostate1, "ON"); else pubMQTT(comandostate1, "OFF");
                if (String(data[2]) == "1" ) pubMQTT(comandostate2, "ON"); else pubMQTT(comandostate2, "OFF");
                if (String(data[3]) == "1" ) pubMQTT(comandostate3, "ON"); else pubMQTT(comandostate3, "OFF");
                if (String(data[4]) == "1" ) pubMQTT(comandostate4, "ON"); else pubMQTT(comandostate4, "OFF");
                if (String(data[5]) == "1" ) pubMQTT(comandostate5, "ON"); else pubMQTT(comandostate5, "OFF");
                if (String(data[6]) == "1" ) pubMQTT(comandostate6, "ON"); else pubMQTT(comandostate6, "OFF");
                if (String(data[7]) == "1" ) pubMQTT(comandostate7, "ON"); else pubMQTT(comandostate7, "OFF");
                if (String(data[8]) == "1" ) pubMQTT(comandostate8, "ON"); else pubMQTT(comandostate8, "OFF");
                if (String(data[9]) == "1" ) pubMQTT(comandostate9, "ON"); else pubMQTT(comandostate9, "OFF");
                if (String(data[10]) == "1" ) pubMQTT(comandostate10, "ON"); else pubMQTT(comandostate10, "OFF");
                if (String(data[11]) == "1" ) pubMQTT(comandostate11, "ON"); else pubMQTT(comandostate11, "OFF");
                if (String(data[12]) == "1" ) pubMQTT(comandostate12, "ON"); else pubMQTT(comandostate12, "OFF");
                if (String(data[13]) == "1" ) pubMQTT(comandostate13, "ON"); else pubMQTT(comandostate13, "OFF");
                if (String(data[14]) == "1" ) pubMQTT(comandostate14, "ON"); else pubMQTT(comandostate14, "OFF");
                if (String(data[15]) == "1" ) pubMQTT(sensor1, "ON"); else pubMQTT(sensor1, "OFF");
                if (String(data[16]) == "1" ) pubMQTT(sensor2, "ON"); else pubMQTT(sensor2, "OFF");
                if (String(data[17]) == "1" ) pubMQTT(sensor3, "ON"); else pubMQTT(sensor3, "OFF");
                digitalWrite(2, !digitalRead(2));


        }

        ESP.wdtFeed();
        last_loop = millis();

}
